#include "pins.h"

void run()
{
	INIT();

while(1)
{
NOTE(76); 
NOTE(75); 
NOTE(76); 
NOTE(75); 
NOTE(76); 
NOTE(71); 
NOTE(74); 
NOTE(72); 
NOTE(69); 
NOTE(69); 
NOTE(69); 

NOTE(60); 
NOTE(64); 
NOTE(69); 
NOTE(71);
NOTE(71);
NOTE(71);

NOTE(64); 
NOTE(68); 
NOTE(71); 
NOTE(72); 
NOTE(72); 
NOTE(72); 


NOTE(64); 


NOTE(76); 
NOTE(75); 
NOTE(76); 
NOTE(75); 
NOTE(76); 
NOTE(71); 
NOTE(74); 
NOTE(72); 
NOTE(69); 
NOTE(69); 
NOTE(69); 

NOTE(60); 
NOTE(64); 
NOTE(69); 
NOTE(71);
NOTE(71);
NOTE(71);


NOTE(64); 
NOTE(72); 
NOTE(71); 
NOTE(69); 
NOTE(69); 
NOTE(69); 

NOTE(71); 
NOTE(72); 
NOTE(74); 
NOTE(76); 
NOTE(76); 
NOTE(76); 

NOTE(69); 
NOTE(77); 
NOTE(76); 
NOTE(74); 
NOTE(74); 
NOTE(74); 

NOTE(67); 
NOTE(76); 
NOTE(74); 
NOTE(72); 
NOTE(72); 
NOTE(72); 

NOTE(65); 
NOTE(74); 
NOTE(72); 
NOTE(71); 
NOTE(71); 
NOTE(71); 

NOTE(64); 
NOTE(64); 
NOTE(64); 

NOTE(76); 
NOTE(75); 
NOTE(76); 
NOTE(75); 
NOTE(76); 
NOTE(71); 
NOTE(74); 
NOTE(72); 
NOTE(69); 
NOTE(69); 
NOTE(69); 

NOTE(60); 
NOTE(64); 
NOTE(69); 
NOTE(71);
NOTE(71);
NOTE(71);

NOTE(64); 
NOTE(68); 
NOTE(71); 
NOTE(72); 
NOTE(72); 
NOTE(72); 

NOTE(64); 


NOTE(76); 
NOTE(75); 
NOTE(76); 
NOTE(75); 
NOTE(76); 
NOTE(71); 
NOTE(74); 
NOTE(72); 
NOTE(69); 
NOTE(69); 
NOTE(69); 

NOTE(60); 
NOTE(64); 
NOTE(69); 
NOTE(71);
NOTE(71);
NOTE(71);


NOTE(64); 
NOTE(72); 
NOTE(71); 
NOTE(69); 
NOTE(69); 
NOTE(69); 

MUTE();
BREAK();
}	
	
	/*int note = 60;
	while (1)
	{
		NOTE(note);
		if (++note == 72) note = 60;
		//MUTE();
	}*/
}