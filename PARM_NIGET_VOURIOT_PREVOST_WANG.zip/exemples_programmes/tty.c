#include "pins.h"

void run()
{
	INIT();
	PUTCHAR('P');
	PUTCHAR('A');
	PUTCHAR('R');
	PUTCHAR('M');
	PUTCHAR('E');
	PUTCHAR('S');
	PUTCHAR('A');
	PUTCHAR('N');
	PUTCHAR('!');
	while (1);
}